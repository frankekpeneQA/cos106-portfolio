# Frank Ekpene - COS 106 Term Project

Responsive student portfolio and academic planner (HTML, CSS, JavaScript).

Pages: index, about, projects, planner, contact.
Edit the project text in projects.html.
Host free with GitHub Pages: push this folder to a repo, then Settings > Pages > deploy from the main branch.
